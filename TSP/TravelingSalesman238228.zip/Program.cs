﻿using RectilinearSteinerArborescence;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TSP
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Point> points = new List<Point>();
            points.Add(new Point(1, 1, 0));
            points.Add(new Point(7, 1, 1));
            points.Add(new Point(1, 4, 2));
            points.Add(new Point(7, 4, 3));

            //int[,] weights = new int[,]
            //{
            //    {0,1,15,6},
            //    {2,0,7,3},
            //    {9,6,0,12},
            //    {10,4,8,0}
            //};
            int[,] weights = new int[,]
{
                            {0,10,15,20},
                            {5,0,9,10},
                            {6,13,0,12},
                            {8,8,9,0}
};
            // Console.WriteLine((1 << 4) - 1);
            // Console.WriteLine((weights.GetLength(0)));
            // for (int i = 0; i <= 4; i++)
            // {
            //     Console.WriteLine(1 << i);
            //     Console.WriteLine("1& " + (1 << i) + " " + (1 & (1 << i)));
            // }
            // int[,] memorizeArray = new int[weights.GetLength(0), 1 << weights.GetLength(0)];

            //// Console.WriteLine(memorizeArray[1, 1]);

            // Console.WriteLine((1 & (1 << 0)));

            TravelingSalesman ts = new TravelingSalesman(weights, points.ElementAt(0), points);

            ts.tspPrepeare();
            foreach(Point p in ts.LowerCostVertex)
            {
                Console.WriteLine(p);
            }
            Console.WriteLine(ts.MinimumCost);
            
        }
    }
}
